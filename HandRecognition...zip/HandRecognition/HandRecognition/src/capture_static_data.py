import cv2
import mediapipe as mp
import numpy as np
import pandas as pd
import os
from datetime import datetime

# === SETTINGS ===
SAVE_PATH = "data/static"
GESTURE_NAME = "attention"      # <<< Change this for each gesture
NUM_SAMPLES = 100

# === Setup ===
os.makedirs(SAVE_PATH, exist_ok=True)
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

# === Webcam ===
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ ERROR: Webcam not opening.")
    exit()

print(f"🎥 Capturing {NUM_SAMPLES} samples for '{GESTURE_NAME}'")
print("👉 Press 's' to start collecting. Press 'q' to quit early.")

data = []
count = 0
collecting = False

while True:
    ret, frame = cap.read()
    if not ret:
        print("⚠️ Skipping frame...")
        continue

    image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(image_rgb)

    if result.multi_hand_landmarks:
        hand_landmarks = result.multi_hand_landmarks[0]
        mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        if collecting and count < NUM_SAMPLES:
            features = np.array([[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark]).flatten()
            data.append(np.append(features, GESTURE_NAME))
            count += 1
            print(f"✅ Captured: {count}/{NUM_SAMPLES}")

    # Display
    status_text = f"Samples: {count}/{NUM_SAMPLES}  | Press 's' to start"
    cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    cv2.imshow("Capture Static Gesture", frame)

    key = cv2.waitKey(10)
    if key == ord('s'):
        collecting = True
        print("📸 Started capturing...")
    elif key == ord('q'):
        print("👋 Quitting early.")
        break

    if count >= NUM_SAMPLES:
        print("✅ Done!")
        break

cap.release()
cv2.destroyAllWindows()

# === Save CSV ===
filename = f"{GESTURE_NAME}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
df = pd.DataFrame(data)
df.to_csv(os.path.join(SAVE_PATH, filename), index=False, header=False)
print(f"💾 Data saved to: {os.path.join(SAVE_PATH, filename)}")
