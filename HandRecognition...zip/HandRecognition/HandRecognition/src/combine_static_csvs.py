import os
import pandas as pd

base_path = "data/static"
all_data = []

# Loop through gesture folders or CSVs
for file in os.listdir(base_path):
    file_path = os.path.join(base_path, file)
    if file.endswith(".csv"):
        print(f"🔗 Loading: {file}")
        df = pd.read_csv(file_path, header=None)
        all_data.append(df)

# Combine and shuffle
combined_df = pd.concat(all_data, ignore_index=True).sample(frac=1).reset_index(drop=True)

# Save combined dataset
combined_df.to_csv("data/static_combined.csv", index=False, header=False)
print("✅ Combined CSV saved to data/static_combined.csv")
