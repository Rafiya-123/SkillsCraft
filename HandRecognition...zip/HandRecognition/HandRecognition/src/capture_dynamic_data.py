import cv2
import mediapipe as mp
import numpy as np
import os
from collections import deque

# CONFIG
SEQUENCE_LENGTH = 30
GESTURE_NAME = "circle"  # 👈 Change this before each run
SAVE_PATH = f"data/dynamic/{GESTURE_NAME}"
os.makedirs(SAVE_PATH, exist_ok=True)

# Init MediaPipe
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

# Init Webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Webcam not accessible.")
    exit()

print(f"📸 Capturing dynamic gesture: {GESTURE_NAME}")
print("👉 Press 's' to start collecting | 'q' to quit")

sequence = deque(maxlen=SEQUENCE_LENGTH)
sample_count = 0

collecting = False

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(frame_rgb)

    if result.multi_hand_landmarks:
        lm = result.multi_hand_landmarks[0]
        mp_drawing.draw_landmarks(frame, lm, mp_hands.HAND_CONNECTIONS)

        # Landmark vector
        landmarks = np.array([[p.x, p.y, p.z] for p in lm.landmark]).flatten()
        sequence.append(landmarks)

        if collecting and len(sequence) == SEQUENCE_LENGTH:
            np.save(os.path.join(SAVE_PATH, f"{GESTURE_NAME}_{sample_count}.npy"), np.array(sequence))
            print(f"✅ Saved sequence {sample_count}")
            sample_count += 1
            sequence.clear()

    # UI text
    status = f"{GESTURE_NAME} | Sequences: {sample_count} | Press 's' to start"
    cv2.putText(frame, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    cv2.imshow("Dynamic Gesture Recorder", frame)

    key = cv2.waitKey(10)
    if key == ord('s'):
        collecting = True
        print("▶️ Started recording sequences.")
    elif key == ord('q'):
        print("🛑 Exiting...")
        break

cap.release()
cv2.destroyAllWindows()
