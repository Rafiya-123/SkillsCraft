import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping

# Load data
df = pd.read_csv("data/static_combined.csv", header=None)

X = df.iloc[:, :-1].values.astype(np.float32)     # 63 features
y = df.iloc[:, -1].values                         # Labels

# Encode labels
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)
y_categorical = to_categorical(y_encoded)

# Save label mapping
label_map = dict(zip(encoder.classes_, encoder.transform(encoder.classes_)))
with open("models/label_map.txt", "w") as f:
    for label, idx in label_map.items():
        f.write(f"{idx}:{label}\n")

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y_categorical, test_size=0.2, random_state=42)

# Build MLP model
model = Sequential([
    Dense(128, activation='relu', input_shape=(63,)),
    Dropout(0.3),
    Dense(64, activation='relu'),
    Dropout(0.3),
    Dense(y_categorical.shape[1], activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train
es = EarlyStopping(patience=5, restore_best_weights=True)
model.fit(X_train, y_train, epochs=100, batch_size=16, validation_split=0.2, callbacks=[es])

# Evaluate
loss, acc = model.evaluate(X_test, y_test)
print(f"✅ Test Accuracy: {acc * 100:.2f}%")

# Save
model.save("models/mlp_model.h5")
print("💾 Model saved to models/mlp_model.h5")
