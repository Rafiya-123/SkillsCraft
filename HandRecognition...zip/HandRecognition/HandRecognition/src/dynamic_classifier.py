import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical

# --- Config ---
DATA_PATH = "data/dynamic"
SEQUENCE_LENGTH = 30
SAVE_MODEL_PATH = "models/lstm_model.h5"
SAVE_LABEL_MAP = "models/lstm_label_map.txt"

# --- Load Data ---
sequences = []
labels = []

for gesture_name in os.listdir(DATA_PATH):
    gesture_folder = os.path.join(DATA_PATH, gesture_name)
    if not os.path.isdir(gesture_folder):
        continue
    for file in os.listdir(gesture_folder):
        if file.endswith(".npy"):
            sequence = np.load(os.path.join(gesture_folder, file))
            if sequence.shape == (SEQUENCE_LENGTH, 63):
                sequences.append(sequence)
                labels.append(gesture_name)

X = np.array(sequences)
y = np.array(labels)

# --- Encode Labels ---
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)
y_categorical = to_categorical(y_encoded)

# Save label mapping
with open(SAVE_LABEL_MAP, "w") as f:
    for idx, label in enumerate(encoder.classes_):
        f.write(f"{idx}:{label}\n")

# --- Split ---
X_train, X_test, y_train, y_test = train_test_split(X, y_categorical, test_size=0.2, random_state=42)

# --- Build LSTM Model ---
model = Sequential([
    LSTM(64, return_sequences=True, input_shape=(SEQUENCE_LENGTH, 63)),
    Dropout(0.3),
    LSTM(64),
    Dropout(0.3),
    Dense(64, activation='relu'),
    Dense(y_categorical.shape[1], activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# --- Train ---
model.fit(X_train, y_train, epochs=50, batch_size=16, validation_split=0.2)

# --- Evaluate ---
loss, acc = model.evaluate(X_test, y_test)
print(f"✅ LSTM Test Accuracy: {acc * 100:.2f}%")

# --- Save Model ---
model.save(SAVE_MODEL_PATH)
print(f"💾 Saved LSTM model to {SAVE_MODEL_PATH}")
