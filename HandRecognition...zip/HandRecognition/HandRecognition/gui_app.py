import tkinter as tk
from tkinter import Label, Text, END
import cv2
import threading
from PIL import Image, ImageTk, ImageOps
import numpy as np
from collections import deque
import mediapipe as mp
from tensorflow.keras.models import load_model

# Load models
mlp_model = load_model("models/mlp_model.h5")
lstm_model = load_model("models/lstm_model.h5")

# Load label maps
def load_label_map(path):
    with open(path, 'r') as f:
        lines = f.readlines()
    return {int(idx): label for idx, label in (line.strip().split(":") for line in lines)}

mlp_label_map = load_label_map("models/label_map.txt")
lstm_label_map = load_label_map("models/lstm_label_map.txt")

# Init MediaPipe
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

sequence_buffer = deque(maxlen=30)

class StylishApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🤖 EchoGestures - AI Hand Recognition")
        self.root.configure(bg="#101820")
        self.root.geometry("960x720")

        self.title_label = Label(root, text="🖐️ EchoGestures: Real-Time Hand Gesture AI", font=("Helvetica", 20, "bold"),
                                 bg="#101820", fg="#00FFC6", pady=20)
        self.title_label.pack()

        self.video_label = Label(root, bg="#202830", bd=3, relief="groove")
        self.video_label.pack(pady=10)

        self.static_label = Label(root, text="Static: Detecting...", font=("Arial", 16, "bold"),
                                  bg="#101820", fg="#FFD700")
        self.static_label.pack(pady=5)

        self.dynamic_label = Label(root, text="Dynamic: Waiting...", font=("Arial", 16, "bold"),
                                   bg="#101820", fg="#00BFFF")
        self.dynamic_label.pack(pady=5)

        self.log_box = Text(root, height=10, width=80, bg="#1C1C1C", fg="#39FF14",
                            font=("Courier", 10), bd=2, relief="sunken")
        self.log_box.pack(pady=15)

        self.cap = cv2.VideoCapture(0)
        self.running = True

        self.start_thread()

    def start_thread(self):
        threading.Thread(target=self.video_loop, daemon=True).start()

    def video_loop(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                continue

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(frame_rgb)

            static_pred, dynamic_pred = "No hand", "..."

            landmark_vector = self.extract_landmarks(results)

            if landmark_vector is not None:
                # Static prediction
                static_input = np.expand_dims(landmark_vector, axis=0)
                mlp_pred = mlp_model.predict(static_input, verbose=0)
                static_class = np.argmax(mlp_pred)
                static_pred = mlp_label_map.get(static_class, "Unknown")

                # Dynamic prediction
                sequence_buffer.append(landmark_vector)
                if len(sequence_buffer) == 30:
                    dyn_input = np.expand_dims(sequence_buffer, axis=0)
                    lstm_pred = lstm_model.predict(dyn_input, verbose=0)
                    dyn_class = np.argmax(lstm_pred)
                    dynamic_pred = lstm_label_map.get(dyn_class, "Unknown")

            # Draw hand
            if results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)

            self.update_ui(frame, static_pred, dynamic_pred)

    def extract_landmarks(self, results):
        if results.multi_hand_landmarks:
            hand = results.multi_hand_landmarks[0]
            return np.array([[lm.x, lm.y, lm.z] for lm in hand.landmark]).flatten()
        return None

    def update_ui(self, frame, static_pred, dynamic_pred):
        frame = cv2.resize(frame, (640, 480))
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        img = ImageOps.expand(img, border=10, fill="#303030")  # border for style
        imgtk = ImageTk.PhotoImage(image=img)
        self.video_label.imgtk = imgtk
        self.video_label.configure(image=imgtk)

        self.static_label.config(text=f"✋ Static: {static_pred}")
        self.dynamic_label.config(text=f"🌀 Dynamic: {dynamic_pred}")

        log_entry = f"Static: {static_pred} | Dynamic: {dynamic_pred}\n"
        self.log_box.insert(END, log_entry)
        self.log_box.see(END)

    def on_close(self):
        self.running = False
        self.cap.release()
        self.root.destroy()

# Run App
if __name__ == "__main__":
    root = tk.Tk()
    app = StylishApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
