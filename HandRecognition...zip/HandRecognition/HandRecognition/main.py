import cv2
import numpy as np
from collections import deque
import mediapipe as mp
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical

# --- Load Models ---
mlp_model = load_model("models/mlp_model.h5")
lstm_model = load_model("models/lstm_model.h5")

# --- Load Label Maps ---
def load_label_map(path):
    with open(path, 'r') as f:
        lines = f.readlines()
    label_map = {}
    for line in lines:
        idx, label = line.strip().split(":")
        label_map[int(idx)] = label
    return label_map

mlp_label_map = load_label_map("models/label_map.txt")
lstm_label_map = load_label_map("models/lstm_label_map.txt")

# --- Init MediaPipe ---
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

# --- Real-time Setup ---
cap = cv2.VideoCapture(0)
sequence_buffer = deque(maxlen=30)

def get_landmark_vector(results):
    if results.multi_hand_landmarks:
        hand = results.multi_hand_landmarks[0]
        return np.array([[lm.x, lm.y, lm.z] for lm in hand.landmark]).flatten()
    return None

print("📡 Starting real-time recognition. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(image_rgb)

    static_pred = "No hand"
    dynamic_pred = "..."

    landmark_vector = get_landmark_vector(results)
    if landmark_vector is not None:
        # Static Prediction
        static_input = np.expand_dims(landmark_vector, axis=0)
        mlp_pred = mlp_model.predict(static_input, verbose=0)
        static_class = np.argmax(mlp_pred)
        static_pred = mlp_label_map.get(static_class, "Unknown")

        # Dynamic Prediction
        sequence_buffer.append(landmark_vector)
        if len(sequence_buffer) == 30:
            dynamic_input = np.expand_dims(sequence_buffer, axis=0)
            lstm_pred = lstm_model.predict(dynamic_input, verbose=0)
            dynamic_class = np.argmax(lstm_pred)
            dynamic_pred = lstm_label_map.get(dynamic_class, "Unknown")

        # Draw landmarks
        mp_drawing.draw_landmarks(frame, results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)

    # Display predictions
    cv2.putText(frame, f"Static: {static_pred}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
    cv2.putText(frame, f"Dynamic: {dynamic_pred}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)

    cv2.imshow("Hand Gesture Recognition", frame)

    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
